<?php

$nick = trim($HTTP_GET_VARS['nick']);
$nick = str_replace("<","",$nick);
$nick = str_replace(">","",$nick);
$nick = str_replace("`","",$nick);
$nick = str_replace(" ","",$nick);
$nick = substr($nick,0,15);
if (empty($nick)) { $nick = "TanpaNama"; }

?>
<html>
<head>
<script>
function kirim() {
  document.formulir.kalimat.value=document.formulir.tulis.value;
  document.formulir.tulis.value="";
  document.formulir.tulis.focus();
}
</script>
</head>
<body bgcolor=#d0d0d0 onload="document.formulir.tulis.focus()">

<table border=0 cellpadding=0 cellspacing=0 width=100%>
<tr>
<td><?php echo "$nick &nbsp;"; ?></td>
<form action="show.php#bawah" target=satu method=post name=formulir onsubmit="kirim()">
<input type=hidden name=kalimat>
<input type=hidden name=nick <?php echo "value=\"$nick\""; ?> >
<td><input type=text name=tulis size=65></td>
</form>
<td align=right>Ganti Alias &raquo; &nbsp;</td>
<form action="tulis.php" method=get name=formulir2>
<td align=right><input type=text name=nick size=10></td>
</form>
</tr>
</table>

</body>
</html>