<?php

$nick = trim($HTTP_POST_VARS['nick']);
$nick = str_replace("<","",$nick);
$nick = str_replace(">","",$nick);
$nick = str_replace("`","",$nick);
$nick = str_replace(" ","",$nick);
$nick = substr($nick,0,15);
if (empty($nick)) { $nick = "TanpaNama"; }

echo "
<html>
<head><title>rautan+ chat</title></head>
<FRAMESET ROWS=\"*,60\" BORDER=0>
<FRAME SRC=\"show.php#bawah\" noresize BORDER=0 SPACING=0 name=satu>
<FRAME SRC=\"tulis.php?nick=$nick\" noresize BORDER=0 SPACING=0 SCROLL=no name=dua>
</FRAMESET>
</html>
";

?>