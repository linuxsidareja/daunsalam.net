<html>
<head>
<META HTTP-EQUIV="Refresh" CONTENT="10;URL=show.php#bawah">
</head>
<body bgcolor=#ffffff>

<?php

/* isi dengan file chat yang menyimpan isi chatting */
$NAMAFILECHAT = "chat.txt";
/* ------------------------------------------------ */

$nick = $HTTP_POST_VARS['nick'];
$kalimat = $HTTP_POST_VARS['kalimat'];

if ($kalimat == "/clear") {
  $filechat = fopen($NAMAFILECHAT,"w");
  fclose($filechat);
  echo "File sudah kosong";
  die();
}

if ($kalimat == "/info") {
  $ukuranfile = filesize($NAMAFILECHAT);
  echo "$ukuranfile byte";
  die();
}

if (!empty($nick) AND !empty($kalimat)) {
  $hariini = getdate();
  $tgl = $hariini['mday'];
  $bln = $hariini['mon'];
  $jam = $hariini['hours'];
  $menit = $hariini['minutes'];
  $kalimat = stripslashes($kalimat);
  $kalimat = str_replace("<","&lt;",$kalimat);
  $kalimat = str_replace(">","&gt;",$kalimat);
  $kalimat = str_replace("`","'",$kalimat);
  $bicara = "`$tgl.$bln:$jam.$menit``$nick```$kalimat\n";
  $filechat = fopen($NAMAFILECHAT,"a");
  fwrite($filechat,$bicara);
  fclose($filechat);
}

$perintah = "tail -n 17 " . $NAMAFILECHAT;
$outputperintah = "";
$hp = exec($perintah,$outputperintah,$exitcode);
$jumlahbaris = count($outputperintah);

for ($i = 0; $i < $jumlahbaris; $i++) {
  $outputperintah[$i] = str_replace("```","</b> ",$outputperintah[$i]);
  $outputperintah[$i] = str_replace("``","</font></small> <b>",$outputperintah[$i]);
  $outputperintah[$i] = str_replace("`","<small><font color=#a0a0a0>",$outputperintah[$i]);
  echo $outputperintah[$i] . "<br>\n";
}

?>

<a name="bawah">&nbsp;</a>
</body>
</html>
