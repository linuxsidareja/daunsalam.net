<?php

/*---------------------------------------------------------------------
  kapunduang * 12/16/05 5:22PM * yanmarshus * yan@daunsalam.net

  script index.php yang akan tampil pertama kali blog ini dikunjungi
  berfungsi untuk menampilkan artikel yang ada dalam folder artikel
  juga berguna untuk menampilkan satu artikel beserta komentarnya
  beberapa variabel yang bisa dikonfigurasi, lihat file config.php
---------------------------------------------------------------------*/

// catat waktu mulai eksekusi script, sekedar untuk "fun" doang :)
$ts_mulai = time();

include "config.php";

// uji apakah akan menampilkan halaman depan atau sebuah artikel
// dan mengambil variabel get yang berisi nama file artikel
$hal_depan = true;
if (isset($HTTP_GET_VARS['f'])) {
  $file_dipilih = $HTTP_GET_VARS['f'];
  $file_dipilih = ereg_replace("[^A-Za-z0-9_]","",$file_dipilih);
  $file_dipilih = substr($file_dipilih,0,$maks_panjang_nama_file_artikel);
  $hal_depan = false;
}

// mengambil semua nama file yang ada dalam direktori artikel
// kemudian nama file tersebut dimasukkan ke dalam array
// kalau gagal buka direktori, mending ke laut aje ...
if ($hsl_opendir = opendir($dir_artikel)) {
  $i = 0;
  while (false !== ($file = readdir($hsl_opendir))) {
    if ($file != "." && $file != "..") {
      $nama_file[$i] = $file;
      $i++;
    }
  }
  $jml_file = $i;
  closedir($hsl_opendir);
} else {
  die($kalimat_die);
}

// ambil data timestamp semua file artikel, untuk proses pengurutan nantinya
for ($i = 0; $i < $jml_file; $i++) {
  $file = $dir_artikel . $nama_file[$i];
  if (file_exists($file)) {
    $ts_file[$i] = filectime($file);
  }
}

// urutkan array dari timestamp file
// urut mulai yang terbaru ke yang lama
arsort($ts_file);
reset($ts_file);

// pengambilan data dari semua file artikel
// untuk artikel yang akan ditampilkan dibatasi sampai jumlah maksimum
// yang dibolehkan, lihat nilai maks_tampil dalam file konfigurasi
$i = 0; $isi_blog = ""; $opsi_nama = "";
while (list($a,$b) = each($ts_file)) {
  $opsi_nama .= "<option value=\"" . $nama_file[$a] . "\">" . str_replace("_"," ",$nama_file[$a]) . "</option>\n";
  if ($hal_depan && ($i < $maks_tampil)) {
    // mengambil data jumlah komentar
    $file = $dir_hitung . $nama_file[$a];
    if (file_exists($file)) {
      $jml_komentar = file_get_contents($file);
    } else {
      $jml_komentar = 0;
    }
    // mengambil isi artikel
    $file = $dir_artikel . $nama_file[$a];
    if (file_exists($file)) {
      $isi_blog .= file_get_contents($file) . "\n";
      $isi_blog .= "<div class=\"tanggal\">" . date("d-m-Y",filectime($file)) . " &bull; ";
      $isi_blog .= filesize($file) . "Byte &bull; ";
      $isi_blog .= "<a href=\"index.php?f=" . $nama_file[$a] . "\">Komentar</a> (" . $jml_komentar . ")</div>\n";
      $i++;
    }
  }
}

// jika yang akan ditampilkan adalah sebuah artikel
// beserta komentarnya, maka yang akan dilakukan adalah proses berikut ini
if (!$hal_depan) {
  $file = $dir_artikel . $file_dipilih;
  if (file_exists($file)) {
    $isi_blog .= file_get_contents($file) . "\n";
    $isi_blog .= "<div class=\"tanggal\">" . date("d-m-Y",filectime($file)) . " &bull; ";
    $isi_blog .= filesize($file) . "Byte</div>\n";
  }
  $file = $dir_komentar . $file_dipilih;
  if (file_exists($file)) {
    $isi_blog .= "<h3>Komentar</h3>\n";
    $isi_blog .= file_get_contents($file) . "\n";
  }
  // menambahkan form untuk pengisian komentar
  $isi_blog .= "<form action=\"komentar.php\" method=\"post\">\n";
  $isi_blog .= "<input type=\"hidden\" name=\"file_dipilih\" value=\"$file_dipilih\">\n";
  $isi_blog .= "Nama<br><input type=\"text\" name=\"nama\"><br>\n";
  $isi_blog .= "Komentar<br><textarea name=\"komentar\" cols=\"39\" rows=\"5\"></textarea><br>\n";
  $isi_blog .= "<input type=\"submit\" value=\" Kirim Komentar \">\n";
  $isi_blog .= "</form>\n";
}

// catat lagi waktu
$ts_selesai = time();
$lama_proses = $ts_selesai - $ts_mulai;


// selesai semuanya yang diperlukan
// inilah waktunya menampilkan halaman kita ke web browser
// jika ingin mengganti bentuk halaman, silahkan atur disini

echo <<<AKHIRHTML
<html>
<head>
<title>Kapunduang</title>
<link type="text/css" rel="stylesheet" href="kapunduang.css">
</head>
<body>

<div class="logo"><a href="index.php">$logo</a></div>

<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td valign="top">
$isi_blog
<br>
</td>
<td valign="top" width="227">
<div class="biodata">
$biodata
</div>
</td>
</tr>
</table>

<form action="index.php" method="get">
<b>Daftar File Selengkapnya</b><br>
<select name="f">
$opsi_nama
</select><br>
<input type="submit" value=" Tampilkan ">
</form>

<div class="kaki">
Halaman ini menggunakan Kapunduang&trade;
dan diproses dalam waktu $lama_proses detik
</div>

</body>
</html>
AKHIRHTML;

?>
