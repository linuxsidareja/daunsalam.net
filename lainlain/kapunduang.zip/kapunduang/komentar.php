<?php

/*---------------------------------------------------------------------
  kapunduang * 12/16/05 5:22PM * yanmarshus * yan@daunsalam.net

  script ini berguna untuk menulis komentar yang ditulis oleh
  pengunjung ke dalam file yang ada dalam direktori komentar,
  sesuai dengan artikel yang dimaksud
---------------------------------------------------------------------*/

include "config.php";

$tanggal = date("d-m-Y");
$firefox = "<s>Firefox</s>";
$hal_redirect = "index.php";

// menerima variabel post dari user (dari halaman index.php)
if (strstr($_SERVER["HTTP_USER_AGENT"],"Firefox")) { $firefox = "Firefox"; }
if (isset($HTTP_POST_VARS['komentar'])) { $komentar = trim($HTTP_POST_VARS['komentar']); }
if (isset($HTTP_POST_VARS['nama'])) { $nama = trim($HTTP_POST_VARS['nama']); }
if (isset($HTTP_POST_VARS['file_dipilih'])) { $file_dipilih = trim($HTTP_POST_VARS['file_dipilih']); }

// adalah baik untuk membersihkan data yang diterima dari unsur yang tidak menarik :)
$nama = htmlspecialchars($nama);
$komentar = htmlspecialchars($komentar);
$file_dipilih = ereg_replace("[^A-Za-z0-9_]","",$file_dipilih);
$file_dipilih = substr($file_dipilih,0,$maks_panjang_nama_file_artikel);
if (empty($nama)) { $nama = "Anonim"; }
$komentar = substr($komentar,0,$maks_ukuran_komentar);

// mengisi variabel dengan data yang sudah terformat untuk html
// data dalam variabel ini yang akan ditulis ke dalam file
$isi_komentar = <<<EOV
<div class="komentar">
<b>$nama</b><br>
$komentar <br>
$tanggal $firefox
</div>
EOV;

// mari mulai menulis isi komentar yang sudah diformat tersebut ke dalam file
$tambah_hitung = false;
$file = $dir_artikel . $file_dipilih;
if (file_exists($file)) {
  $hal_redirect = "index.php?f=" . $file_dipilih;
  if (!empty($komentar)) {
    $file = $dir_komentar . $file_dipilih;
    if (filesize($file) < $maks_ukuran_file_komentar) {
      if ($hsl_fopen = fopen($file,"a")) {
        fwrite($hsl_fopen,$isi_komentar);
        fclose($hsl_fopen);
        $tambah_hitung = true;
      }
    }
  }
}

// jika sebuah komentar sudah ditambahkan, naikkan nilai hitung
// dalam file hitung yang bersesuaian dengan komentar ini
if ($tambah_hitung) {
$file = $dir_hitung . $file_dipilih;
  if (file_exists($file)) {
    $angka = file_get_contents($file);
  } else {
    $angka = 0;
  }
  $angka = $angka + 1;
  if ($hsl_fopen = fopen($file,"w")) {
    fwrite($hsl_fopen,$angka);
    fclose($hsl_fopen);
  }
}

// selesai tugas script ini
// saatnya untuk mengarahkan pemakai kembali ke halaman sebelumnya
echo <<<EOH
<html><head>
<META HTTP-EQUIV="Refresh" CONTENT="0;URL=$hal_redirect">
</head><body></body></html>
EOH;

?>
