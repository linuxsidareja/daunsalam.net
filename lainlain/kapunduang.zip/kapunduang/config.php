<?php

/*---------------------------------------------------------------------
  kapunduang * 12/16/05 4:56PM * yanmarshus * yan@daunsalam.net

  ini adalah file konfigurasi kapunduang
  nilai yang sudah ada di sini sudah cukup untuk menjadikan
  sistem berjalan sebagaimana mestinya
  kalau anda ingin yang lain, silahkan diganti
---------------------------------------------------------------------*/

/*---------------------------------------------------------------------
  tentukan error yang akan dimunculkan
  kalau digunakan ketika pembuatan/perbaikan, sebaiknya set ke E_ALL
  jika digunakan untuk "mengudara" sebaiknya set ke 0
---------------------------------------------------------------------*/
error_reporting(E_ERROR);
$kapunduang_ver = "0.09";

/*---------------------------------------------------------------------
  nama untuk direktori yang digunakan sebagai penyimpan data
  jika akan diganti perhatikan bahwa direktori tersebut ada
  semua direktori ini berada dalam direktori data
---------------------------------------------------------------------*/
$nama_folder_artikel = 'artikel';
$nama_folder_komentar = 'komentar';
$nama_folder_gudang = 'gudang';
$nama_folder_hitung = 'hitung';

/*---------------------------------------------------------------------
  maks_tampil adalah jumlah maksimum artikel yang ditampilkan
    di halaman depan/homepage
  logo adalah gambar di bagian atas halaman
  biodata adalah kalimat yang ditampilkan di kolom sebelah kanan
    halaman, bisa diisi tentang diri atau informasi lainnya
  kalimat_die adalah kalimat yang akan ditampilkan jika terjadi
    kesalahan fatal
---------------------------------------------------------------------*/
$maks_tampil = 7;
$logo = '<img src="logo.gif" alt="Kapunduang" border="0">';
$biodata = "Kapunduang versi $kapunduang_ver<br>Sebuah program blog minimalis. Dibuat untuk memenuhi kebutuhan para penganut paham primitif. Yang tertarik, silahkan mengambil source code, lalu sebaiknya jika memiliki perbaikan atau penambahan fitur, bisa dikirim kembali ke email yan at daunsalam dot net. Agar digabungkan kembali di sini. <a href=\"kapunduang.zip\"><b>Download Kapunduang</b></a>";
$kalimat_die = 'Script panik! Sepertinya minum teh bisa menenangkan Anda';

/*---------------------------------------------------------------------
  maks_ukuran_file_komentar adalah ukuran maksimum untuk sebuah
    file komentar, atur sesuai keperluan, sebaiknya bertindak
    tradisional saja dengan ukuran yang sedang
  maks_ukuran_file_artikel adalah ukuran maksimum sebuah file
    artikel
  maks_ukuran_komentar adalah ukuran maksimum untuk sebuah komentar
    yang dikirim pengunjung. sebaiknya angka ini tetap kecil.
  maks_panjang_nama_file_artikel adalah panjang maksimum untuk
    nama file artikel
---------------------------------------------------------------------*/
$maks_ukuran_file_komentar = 131072;
$maks_ukuran_file_artikel = 131072;
$maks_ukuran_komentar = 2048;
$maks_panjang_nama_file_artikel = 128;

/*---------------------------------------------------------------------
sebaiknya tidak merubah apa yang ada di bawah ini
---------------------------------------------------------------------*/

$dir_artikel = './data/' . $nama_folder_artikel . '/';
$dir_komentar = './data/' . $nama_folder_komentar . '/';
$dir_gudang = './data/' . $nama_folder_gudang . '/';
$dir_hitung = './data/' . $nama_folder_hitung . '/';

?>
