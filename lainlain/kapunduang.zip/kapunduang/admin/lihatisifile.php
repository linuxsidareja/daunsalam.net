<?php

/*---------------------------------------------------------------------
  kapunduang * 12/16/05 8:02PM * yanmarshus * yan@daunsalam.net

  script lihatisifile.php untuk menampilkan isi sebuah file
---------------------------------------------------------------------*/

include "../config.php";

// menerima variabel get
if (isset($HTTP_GET_VARS['nama'])) { $nama = $HTTP_GET_VARS['nama']; }
if (isset($HTTP_GET_VARS['dir'])) { $dir = $HTTP_GET_VARS['dir']; }

// menguji nama folder, dan nama file
if (($dir != $nama_folder_artikel) && ($dir != $nama_folder_komentar) && ($dir != $nama_folder_gudang)) {
  $dir = $nama_folder_artikel;
}
$nama = ereg_replace("[^A-Za-z0-9_]","",$nama);
$nama = substr($nama,0,$maks_panjang_nama_file_artikel);

// baca isi file dan masukkan ke dalam variabel $isi_file
$file = "../data/" . $dir . "/" . $nama;
if (file_exists($file)) {
  $isi_file = file_get_contents($file);
  $isi_file = htmlspecialchars($isi_file);
} else {
  $isi_file = "";
}

// ok, tampilkan ke browser
echo <<<EOH
<html>
<head>
<title>Kapunduang</title>
<style type="text/css">
BODY { margin : 25px 50px; }
TEXTAREA {
  border : 1px #404040 solid;
  padding : 10px;
  background : #f0f0f0;
}
</style>
</head>
<body>

<form action=# onSubmit="return false">
<input type="button" value="   OK   " onClick="window.history.go(-1)">
&bull; Isi File <b>$dir</b>/<b>$nama</b>
<br><br>
<textarea cols="77" rows="21">
$isi_file
</textarea>
</form>

</body>
</html>
EOH;

?>
