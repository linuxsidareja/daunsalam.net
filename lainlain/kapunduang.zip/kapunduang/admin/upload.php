<?php

/*---------------------------------------------------------------------
  kapunduang * 12/16/05 6:16PM * yanmarshus * yan@daunsalam.net

  script upload.php untuk menerima file yang diupload,
  kemudian disimpan ke direktori tempat artikel
  hanya bisa melakukan upload ke direktori artikel
---------------------------------------------------------------------*/

include "../config.php";

$dirtujuan = "../data/" . $nama_folder_artikel . "/";

// menerima variabel post
$namaasli = $HTTP_POST_FILES['filekirim']['name'];
$tipeasli = $HTTP_POST_FILES['filekirim']['type'];
$sizeasli = $HTTP_POST_FILES['filekirim']['size'];
$namatemp = $HTTP_POST_FILES['filekirim']['tmp_name'];
$namaasli = ereg_replace("[^A-Za-z0-9_]","",$namaasli);

$tujuanfile = $dirtujuan . $namaasli;

// copy file yang sudah diupload ke direktori data artikel
if (!empty($namaasli)) {
  if (!file_exists($tujuanfile)) {
    if (is_uploaded_file($namatemp)) {
      copy($namatemp, $tujuanfile);
    }
  }
}

// setelah selesai, tampilkan kembali halaman daftar file di direktori data artikel
$hal_redirect = "admin.php?d=" . $nama_folder_artikel;
echo <<<EOH
<html><head>
<META HTTP-EQUIV="Refresh" CONTENT="0;URL=$hal_redirect">
</head><body></body></html>
EOH;

?>
