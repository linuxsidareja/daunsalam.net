<?php

/*---------------------------------------------------------------------
  kapunduang * 12/16/05 6:16PM * yanmarshus * yan@daunsalam.net

  script aksi.php untuk melakukan aksi yang dipilih terhadap file
  yaitu gudangkan, tampilkan, hapus, gantinama
---------------------------------------------------------------------*/

include "../config.php";

// menerima variabel post
if (isset($HTTP_POST_VARS['aksi'])) { $aksi = $HTTP_POST_VARS['aksi']; }
if (isset($HTTP_POST_VARS['nama'])) { $nama = $HTTP_POST_VARS['nama']; }
if (isset($HTTP_POST_VARS['dir'])) { $dir = $HTTP_POST_VARS['dir']; }
if (isset($HTTP_POST_VARS['pilihan'])) { $pilihan = $HTTP_POST_VARS['pilihan']; }

// aksi yang dilakukan untuk memindahkan file yang dipilih di direktori artikel
// ke dalam direktori gudang
if (($aksi == "gudangkan") && ($dir == $nama_folder_artikel) && !empty($pilihan)) {
  while (list($a,$b) = each($pilihan)) {
    $asal = "../data/" . $nama_folder_artikel . "/" . $b;
    $tujuan = "../data/" . $nama_folder_gudang . "/" . $b;
    if (file_exists($asal) && !file_exists($tujuan)) {
      $copy_sukses = false;
      $copy_sukses = copy($asal,$tujuan);
      if ($copy_sukses) { unlink($asal); }
    }
  }
}

// aksi yang dilakukan untuk memindahkan file yang dipilih di direktori gudang
// ke dalam direktori artikel
if (($aksi == "tampilkan") && ($dir == $nama_folder_gudang) && !empty($pilihan)) {
  while (list($a,$b) = each($pilihan)) {
    $asal = "../data/" . $nama_folder_gudang . "/" . $b;
    $tujuan = "../data/" . $nama_folder_artikel . "/" . $b;
    if (file_exists($asal) && !file_exists($tujuan)) {
      $copy_sukses = false;
      $copy_sukses = copy($asal,$tujuan);
      if ($copy_sukses) { unlink($asal); }
    }
  }
}

// menghapus file yang dipilih
if (($aksi == "hapus") && !empty($pilihan)) {
  reset($pilihan);
  while (list($a,$b) = each($pilihan)) {
    $file = "../data/" . $dir . "/" . $b;
    if (file_exists($file)) {
      unlink($file);
      // jika yang dihapus adalah file komentar, hapus juga file hitung
      if ($dir == $nama_folder_komentar) {
        $file = "../data/" . $nama_folder_hitung . "/" . $b;
        if (file_exists($file)) { unlink($file); }
      }
    }
  }
}

// ganti nama file. jika file yang dipilih ada beberapa buah,
// maka yang diganti namanya hanya satu, yang berada di urutan pertama
// dari variabel pilihan
if (($aksi == "gantinama") && !empty($pilihan) && !empty($nama)) {
  $nama = ereg_replace("[^A-Za-z0-9_]","",$nama);
  $nama = substr($nama,0,$maks_panjang_nama_file_artikel);
  list($a,$b) = each($pilihan);
  $filelama = "../data/" . $dir . "/" . $b;
  $filebaru = "../data/" . $dir . "/" . $nama;
  if (!file_exists($filebaru)) {
    rename($filelama, $filebaru);
  }
}

if (empty($dir)) { $dir = $nama_folder_artikel; }
$hal_redirect = "admin.php?d=" . $dir;

// kirim kembali ke halaman yang menampilkan file
echo <<<EOH
<html><head>
<META HTTP-EQUIV="Refresh" CONTENT="0;URL=$hal_redirect">
</head><body></body></html>
EOH;

?>
