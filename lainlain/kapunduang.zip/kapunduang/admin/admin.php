<?php

/*---------------------------------------------------------------------
  kapunduang * 12/16/05 7:15PM * yanmarshus * yan@daunsalam.net

  script untuk menampilkan file dalam direktori tertentu
  beserta tombol untuk melakukan beberapa pilihan aksi terhadap file
---------------------------------------------------------------------*/

// waktu lagi, waktu lagi
$ts_mulai = time();

include "../config.php";

// menguji nama folder yang akan ditampilkan
$dir_dipilih = $nama_folder_artikel;
if (isset($HTTP_GET_VARS['d'])) {
  $dir_dipilih = $HTTP_GET_VARS['d'];
  if (($dir_dipilih != $nama_folder_artikel) && ($dir_dipilih != $nama_folder_komentar) && ($dir_dipilih != $nama_folder_gudang)) {
    $dir_dipilih = $nama_folder_artikel;
  }
}

$direktori = "../data/" . $dir_dipilih . "/";

// mengambil semua nama file yang ada dalam direktori bersangkutan
// kemudian nama file tersebut dimasukkan ke dalam array
// jika gagal, die!
if ($hsl_opendir = opendir($direktori)) {
  $i = 0;
  while (false !== ($file = readdir($hsl_opendir))) {
    if ($file != "." && $file != "..") {
      $nama_file[$i] = $file;
      $i++;
    }
  }
  $jml_file = $i;
  closedir($hsl_opendir);
} else {
  die($kalimat_die);
}

// penyusunan nama file dalam sebuah tabel html
$warna = false;
$nomor = 0;
$daftar_file = "<table cellspacing=\"1\" cellpadding=\"2\" border=\"0\" width=\"100%\" class=\"tabel_data\">\n";
$daftar_file .= "<tr class=\"tr_judul\"><td>&nbsp;</td><td>Nomor</td><td>Nama File</td><td>Tanggal</td><td>Ukuran (KB)</td><td>&nbsp;</td></tr>\n";
for ($i = 0; $i < $jml_file; $i++) {
  $nomor++;
  if ($warna) { $tr = "<tr class=\"tr_gelap\">"; } else { $tr = "<tr class=\"tr_terang\">"; }
  $warna = !$warna;
  $check_box = "<td align=\"center\"><input type=\"checkbox\" name=\"pilihan[]\" value=\"". $nama_file[$i] . "\"></td>";
  $link_lihat_isi = "<a href=\"lihatisifile.php?dir=" . $dir_dipilih . "&nama=" . $nama_file[$i] . "\">Lihat Isi</a>";

  $file = $direktori . $nama_file[$i];
  $daftar_file .= $tr . $check_box;
  $daftar_file .= "<td align=\"center\">" . $nomor . "</td>";
  $daftar_file .= "<td>" . $nama_file[$i] . "</td>";
  $daftar_file .= "<td align=\"center\">" . date("d-m-Y",filectime($file)) . "</td>";
  $daftar_file .= "<td>" . round((filesize($file)/1024),1) . "</td>\n";
  $daftar_file .= "<td align=\"center\">" . $link_lihat_isi . "</td></tr>\n";
}
$daftar_file .= "</table>\n";

// penyusunan untuk tampilan link ke direktori
$link_artikel = "<a href=\"admin.php?d=$nama_folder_artikel\">Direktori Artikel</a>";
$link_komentar = "<a href=\"admin.php?d=$nama_folder_komentar\">Direktori Komentar</a>";
$link_gudang = "<a href=\"admin.php?d=$nama_folder_gudang\">Direktori Gudang</a>";
if ($dir_dipilih == $nama_folder_artikel) { $link_artikel = "<b>Direktori Artikel</b>"; }
if ($dir_dipilih == $nama_folder_komentar) { $link_komentar = "<b>Direktori Komentar</b>"; }
if ($dir_dipilih == $nama_folder_gudang) { $link_gudang = "<b>Direktori Gudang</b>"; }

// pemilihan tombol untuk gudangkan atau tampilkan
$tbl_pemindahan = "";
if ($dir_dipilih == $nama_folder_artikel) {
  $tbl_pemindahan = "<input type=\"button\" value=\"Gudangkan\" onClick=\"gudangkan()\">";
}
if ($dir_dipilih == $nama_folder_gudang) {
  $tbl_pemindahan = "<input type=\"button\" value=\"Tampilkan\" onClick=\"tampilkan()\">";
}

// menyusun form untuk tombol aksi dan textbox untuk penggantian nama file
$tombol_aksi = <<<EOT
<form action=# name="form_tombol" onSubmit="return false">
<input type="button" value="Hapus" onClick="hapus()">
$tbl_pemindahan
&bull; Nama Baru
<input type="text" name="nama_tulis">
<input type="button" value="Ganti Nama" onClick="gantinama()">
</form>
EOT;

// tapi jika tidak ada file dalam direktori yang dipilih,
// sebaiknya tombol aksi tidak ditampilkan
if ($jml_file == 0) { $tombol_aksi = ""; }

// lagi-lagi waktu
$ts_selesai = time();
$lama_proses = $ts_selesai - $ts_mulai;

// tampilkan data ke browser

echo <<<AKHIRHTML
<html>
<head>
<title>Kapunduang</title>
<link type="text/css" rel="stylesheet" href="admin.css">
<script type="text/javascript">
function hapus() {
  if(confirm('File Akan Dihapus ?')) {
    window.document.formulir.aksi.value = "hapus";
    window.document.formulir.submit();
  }
}
function gudangkan() {
  window.document.formulir.aksi.value = "gudangkan";
  window.document.formulir.submit();
}
function tampilkan() {
  window.document.formulir.aksi.value = "tampilkan";
  window.document.formulir.submit();
}
function gantinama() {
  window.document.formulir.aksi.value = "gantinama";
  window.document.formulir.nama.value = window.document.form_tombol.nama_tulis.value
  window.document.formulir.submit();
}
</script>
</head>
<body>

<h2><a href="../index.php">Kapunduang</a> <small><small>/ Administrasi Blog </small></small></h2>
$link_artikel &bull; $link_komentar &bull; $link_gudang
<br><br>

<form action="aksi.php" method="post" name="formulir">
<input type="hidden" name="aksi">
<input type="hidden" name="nama">
<input type="hidden" name="dir" value="$dir_dipilih">
$daftar_file
</form>
$tombol_aksi

<div class="info">
Untuk menghapus file, pilih file yang akan dihapus, kemudian klik tombol hapus.
File yang ada dalam direktori artikel bisa dipindahkan ke dalam direktori gudang,
demikian juga sebaliknya.
File yang tampil di halaman blog hanyalah yang ada dalam direktori artikel.
Untuk memindahkan file dari direktori artikel ke direktori gudang,
gunakan tombol gudangkan.
Sedangkan untuk memindahkan dari direktori gudang ke direktori artikel,
gunakan tombol tampilkan.
Mengganti nama file bisa dilakukan dengan memilih satu file yang akan dipilih,
kemudian isikan nama baru dalam textbox, lalu klik ganti nama.
Karakter yang dibolehkan untuk nama file dari a-z, A-Z, 0-9, dan tanda _ &nbsp;
Nama file sebaiknya bersesuaian dengan judul artikel.
Untuk melakukan upload file gunakan form di bawah ini. File yang diupload akan
dimasukkan ke direktori artikel.
</div>

<form enctype="multipart/form-data" action="upload.php" method="post">
<input type="hidden" name="max_file_size" value="$maks_ukuran_file_artikel">
File <input name="filekirim" type="file">
<input type="submit" value=" Upload ">
</form>

<div class="kaki">
Halaman ini menggunakan Kapunduang&trade;
dan diproses dalam waktu $lama_proses detik
</div>

</body>
</html>
AKHIRHTML;

?>
