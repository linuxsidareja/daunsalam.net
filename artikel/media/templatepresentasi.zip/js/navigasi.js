/* isi nilai variabel maxhal dengan jumlah halaman */
var maxhal = 4;



var hal = 1;

function hal_sebelum() {
  if (hal > 1) {
    hal = hal - 1;
    halaman = "../isi/" + hal + ".htm";
    top.tengah.location = halaman;
    window.document.pilih.halaman.options[hal-1].selected = true;
  }
}

function hal_berikut() {
  if (hal < maxhal) {
    hal = hal + 1;
    halaman = "../isi/" + hal + ".htm";
    top.tengah.location = halaman;
    window.document.pilih.halaman.options[hal-1].selected = true;
  }
}

function ganti_halaman(halpilih) {
  hal = Number(halpilih);
  halaman = "../isi/" + hal + ".htm";
  top.tengah.location = halaman;
}

function tutup(halpilih) {
  top.close();
}
