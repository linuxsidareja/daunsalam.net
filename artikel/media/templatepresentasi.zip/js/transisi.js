var n = 0;
var warna = ["#000000","#101010","#202020","#303030","#404040","#505050","#606060","#707070","#808080","#909090","#A0A0A0","#B0B0B0","#C0C0C0","#D0D0D0","#E0E0E0","#FFFFE0"];
pewaktu = null;
function ke_terang() {
  n = n + 1;
  if (n < 16) {
     window.document.bgColor = warna[n];
     pewaktu = setTimeout("ke_terang()",50);
  }
}
